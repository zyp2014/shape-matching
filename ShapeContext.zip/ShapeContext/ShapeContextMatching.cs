﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using ShapeContext.Properties;

using LiniarAlgebra;


namespace ShapeContext
{
    /// <Name>          A Shape Context algorithm based matching.   </Name>
    /// <Version>           0.1a Pre release                        </Version>
    /// <FileName>          ShapeContextMatching.cs                 </FileName>
    /// <ClassName>         ShapeContextMatching                    </ClassName>
    /// <OriginalAlgorithmBy>**************************************************
    ///     <Name>          Shaul Gaidelman                         </Name>
    ///     <Email>         shaulg@...                              </Email>
    /// </OriginalAlgorithmBy>
    /// <RefactoredAndModified>
    ///     <Name>          Yanir Tafkev                            </Name>
    ///     <Email>         yanirta@gmail.com                       </Email>
    /// </RefactoredAndModified>***********************************************
    /// <Guidance>
    ///     <Name>                                                  </Name>
    ///     <Email>                                                 </Email>
    /// </Guidance>
    /// <Institution>
    /// </Institution>
    /// <Date>              Aug. - 2009                             </Date>
    /// <License>
    /// This class library is free to use as long as it used unmodified, including the credits above.
    /// For modifications please contact with one of the creators to get the approval.
    /// </License>
    /// <summary>
    /// Shape context is an algorithm matching two monocolored (dark colored) , described by outlines, drawings.
    /// The algorithm gets two sets of points, sampled from the drawings (First from the original,Second from the target). 
    /// Note that the length of the two sets must be identical, otherwise exception is thrown.
    /// The output of the algorithms is array of indexes that indicates for each point from the original set,
    /// what is the corresponding point at the target set.
    /// 
    /// The algorithm provide a good base to identify differences between two shapes, based on the distances betweend
    /// matching points. The more runs of the algorithm, the better indication for the matching.
    /// Some matchings may be false, identify a length for a treshold that suits best for your purposes.
    /// </summary>
    /// <References>
    /// http://en.wikipedia.org/wiki/Shape_context
    /// Matching with Shape Contexts - S. Belongie and J. Malik (2000).
    /// Shape Matching and Object Recognition Using Shape Contexts - S. Belongie, J. Malik, and J. Puzicha (April 2002).
    /// </References>
    /// <SpecialThanks></SpecialThanks>
    public class ShapeContextMatching
    {
        private Point[] m_Shape1Points;     // the original model points
        private Point[] m_Shape2Points;     // the imitation model points

        private DoubleMatrix[] m_Shape1Histogram;
        private DoubleMatrix[] m_Shape2Histogram;

        private int[] m_MatchingsArray;

        public ShapeContextMatching (Point[] i_Shape1Points, Point[] i_Shape2Points)
	    {
            NumOfThetaBins  = int.Parse(Resources.k_DefaultThetaBins);
            NumOfBins       = int.Parse(Resources.k_DefaultNumOfBins);
            NumOfIterations = int.Parse(Resources.k_DefaultNumOfIterations);
            
            m_MatchingsArray    = null;
            
            m_Shape1Points  = i_Shape1Points;
            m_Shape2Points  = i_Shape2Points;
	    }

        /// <summary>
        /// Prepare Shape context matching on the samples that preveously given in the C'tor.
        /// 
        /// Remark: Meanwhite no optimization/relaxing is done, just matching points from the source to the target.
        /// </summary>
        /// <returns>
        /// The result is array of indexes so if we take i'th point from shape1 samples, the corresponding
        /// point is at result[i]'th point in shape2 samples.
        /// </returns>
        public int[] runOnSamples()
        {
            double shape1DistanceAvg, shape2DistanceAvg;
            
            DoubleMatrix costMatrix;

            //CThinPlate thinPlate;

            //Calculate histogram - Next version can be in two threads
            m_Shape1Histogram = calcHistograms(m_Shape1Points, out shape1DistanceAvg);
            m_Shape2Histogram = calcHistograms(m_Shape2Points, out shape2DistanceAvg);
            

            //int[] optimalCostMatrix = null;

            for (int IterationNum = 0; IterationNum < NumOfIterations; ++IterationNum)
            {
                costMatrix = calculateCostMatrix();

                m_MatchingsArray = HungarianAlgorithm.Run(costMatrix);


                break; //remove this break when uncommenting next code
                //if (IterationNum == 0) yanir
                //{ // DEBUG
                //    displayMatch(optimalCostMatrix);
                //}
                
                //betaK = shape2DistanceAvg * shape2DistanceAvg * lambda;
                // thinPlate algorithm
                //thinPlate = new CThinPlate(
                //                    CMatrixManipulation.Points2Matrix(m_Shape2Points),
                //                    CMatrixManipulation.Points2Matrix(m_Shape1Points), betaK);

                //// TRY ALSO TO SOLVE THE EQUASION VIA METHOD, CHECK INTERP !!!!
                //m_Shape2Points = CMatrixManipulation.Matrix2Points(thinPlate.Wrap2());

                if (IterationNum < NumOfIterations - 1)
                { // skip, last iteration

                //    lambda = sr_BetaInit * Math.Pow(sr_R, IterationNum - 2);

                    // Calculate Imitation Histogram 
                    m_Shape2Histogram = calcHistograms(m_Shape2Points, out shape2DistanceAvg);
                }
            }

            //displayMatch(optimalCostMatrix);
            return m_MatchingsArray;
        }

        #region Private Section
        private void calcHistograms(out double o_Shape1DistanceAvg, out double o_Shape2DistanceAvg)
        {
            // original model histogram
            m_Shape1Histogram = Histogram.CreateHistogram(m_Shape1Points, NumOfThetaBins, NumOfBins, out o_Shape1DistanceAvg);

            // imitation model histogram
            m_Shape2Histogram = Histogram.CreateHistogram(m_Shape2Points, NumOfThetaBins, NumOfBins, out o_Shape2DistanceAvg);
        }

        private DoubleMatrix[] calcHistograms(Point[] i_ShapePoints, out double o_ShapecalcHistograms)
        {
            return Histogram.CreateHistogram(i_ShapePoints, NumOfThetaBins, NumOfBins, out o_ShapecalcHistograms);
        }

        /// <summary>
        /// each entry in histogram points to NxM matrix
        /// were N is number of radius(dist rings) and M is the number of bins
        /// </summary>
        /// <returns></returns>
        private DoubleMatrix calculateCostMatrix()
        {
            if (m_Shape1Histogram.Length != m_Shape2Histogram.Length)
            {
                throw new ShapeContextAlgoException("Histogram doesn't have same points number");
            }

            int N = m_Shape2Points.Length;
            DoubleMatrix histogram1, histogram2;
            DoubleMatrix costMatrix = new DoubleMatrix(N);

            for (int i = 0; i < N; ++i)
            { // go over all points histograms

                histogram1 = m_Shape1Histogram[i];
                for (int j = 0; j < N; ++j)
                {
                    histogram2 = m_Shape2Histogram[j];

                    if (histogram1.CellCount != histogram2.CellCount)
                    {
                        throw new ShapeContextAlgoException("Histogram doesn't have same dimension");
                    }

                    costMatrix[i, j] = calcTwoHistogramsCost(histogram1, histogram2);
                }
            }

            return costMatrix;
        }

        private double calcTwoHistogramsCost(DoubleMatrix i_Histogram1, DoubleMatrix i_Histogram2)
        {
            double val1, val2, sum = 0, histogram1Sum, histogram2Sum;
            int rowLen = i_Histogram1.RowsCount, colLen = i_Histogram1.ColumnsCount;

            histogram1Sum = i_Histogram1.Sum();
            histogram2Sum = i_Histogram2.Sum();

            for (int i = 0; i < rowLen; ++i)
            {
                for (int j = 0; j < colLen; ++j)
                {
                    // normelized value
                    val1 = i_Histogram1[i, j] / histogram1Sum;
                    val2 = i_Histogram2[i, j] / histogram2Sum;

                    if ((val1 + val2) != 0)
                    {
                        sum += Math.Pow(val1 - val2, 2) / (val1 + val2);
                    }
                }
            }
            return sum / 2;
        }

        #endregion

        #region Properties

        public int NumOfThetaBins { get; set; }
        public int NumOfBins { get; set; }
        /// <summary>
        /// If optimization/Relaxing method is used, 
        /// NumOfIterations sets the number of times to run that optimization/Relaxing method.
        /// </summary>
        public int NumOfIterations { get; set; }

        /// <summary>
        /// Gets the matchings array.
        /// Note that runOnSamples() should be called before using this one. 
        /// </summary>
        public int[] Matchings
        {
            get
            {
                return m_MatchingsArray;
            }
        }
        #endregion

    }
}
