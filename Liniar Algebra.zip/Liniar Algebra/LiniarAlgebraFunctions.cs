﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiniarAlgebra
{
    public static class LiniarAlgebraFunctions
    {
        /// <summary>
        /// Calculate covarience of N vectors
        /// Each vector has M organs
        /// Assuming that the matrix is mormalized so that the mean of each row is 0
        /// </summary>
        /// <param name="i_MxNmatrix"></param>
        /// <returns></returns>
        public static Matrix<Type> Covarience<Type>(Matrix<Type> i_MxNmatrix) where Type : IComparable<Type>
        {
            int covMatSquareSize = i_MxNmatrix.RowsCount;
            ICalculator<Type> matrixCalc = i_MxNmatrix.Calculator;
            Matrix<Type> retCovMatrix = new Matrix<Type>(covMatSquareSize, i_MxNmatrix.Calculator);
            for (int i = 0; i < covMatSquareSize; ++i)
            {
                for (int j = 0; j <= i; ++j)
                {   ///calculating single vector covarience
                    Type covResult = matrixCalc.Zero();
                    for (int vecIndex = 0; vecIndex < i_MxNmatrix.ColumnsCount; ++vecIndex)
                    {
                        covResult = matrixCalc.Add(
                                        covResult,
                                        matrixCalc.Multiply(
                                            i_MxNmatrix[i, vecIndex], 
                                            i_MxNmatrix[j, vecIndex]
                                                            )
                                                   );
                    }
                    retCovMatrix[i, j] = retCovMatrix[j, i] = matrixCalc.Division(
                                covResult,
                                matrixCalc.FromDouble(i_MxNmatrix.ColumnsCount - 1)
                                                                                  );
                }
            }
            return retCovMatrix;
        }

        /// <summary>
        /// Wraps different implementation from third party
        /// </summary>
        /// <param name="i_MxNmatrix"></param>
        /// <param name="o_EigenValues"></param>
        /// <returns></returns>
        public static DoubleMatrix EigenMatrix(DoubleMatrix i_MxNmatrix,out double[] o_EigenValues)
        {
            double[,] retEigenVectors = EigenValuesFinder.CalcEigenVectors(true, out o_EigenValues, i_MxNmatrix.InnerMatrix);
            return new DoubleMatrix(retEigenVectors);
        }
    }
}
